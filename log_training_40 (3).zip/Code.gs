// مشروع مرتبط بجدول Google Sheets. شغّلي setup مرة واحدة قبل النشر.
const KEY = [0, 2, 1, 1, 2, 2, 1, 2, 1, 2, 2, 1, 0, 1, 2, 0, 1, 0, 2, 1, 2, 1, 1, 0, 1, 2, 1, 2, 0, 1, 2, 2, 2, 1, 0, 1, 0, 2, 1, 0];
function setup(){ const ss=SpreadsheetApp.getActiveSpreadsheet(); if(!ss) throw new Error('افتحي Apps Script من داخل جدول غوغل شيت'); PropertiesService.getScriptProperties().setProperty('SHEET_ID',ss.getId()); let sh=ss.getSheetByName('النتائج'); if(!sh)sh=ss.insertSheet('النتائج'); if(sh.getLastRow()===0)sh.appendRow(['معرف المحاولة','وقت الحفظ','الاسم','الشعبة','الدرجة /40','النسبة %','المدة بالثواني','الخواص /12','التعريف /14','المعادلات /14',...KEY.map((_,i)=>'س'+(i+1))]); sh.setFrozenRows(1); }
function doGet(){return HtmlService.createHtmlOutputFromFile('index').setTitle('تدريب اللوغاريتم النيبري — 40 سؤالًا');}
function submitResult(p){
 if(!p || typeof p.id!=='string' || !/^[a-zA-Z0-9.\-]{10,100}$/.test(p.id) || typeof p.name!=='string' || !p.name.trim() || p.name.length>80 || !Array.isArray(p.answers) || p.answers.length!==40 || p.answers.some(a=>!Number.isInteger(a)||a<0||a>3) || !Number.isFinite(p.seconds)||p.seconds<0||p.seconds>604800)throw new Error('بيانات غير صالحة');
 const lock=LockService.getScriptLock();lock.waitLock(30000);
 try{const id=PropertiesService.getScriptProperties().getProperty('SHEET_ID');if(!id)throw new Error('شغلي setup أولًا');const sh=SpreadsheetApp.openById(id).getSheetByName('النتائج');const score=KEY.reduce((s,k,i)=>s+(k===p.answers[i]?1:0),0);
 if(sh.getLastRow()>1 && sh.getRange(2,1,sh.getLastRow()-1,1).createTextFinder(p.id).matchEntireCell(true).findNext())return {ok:true,score};
 const safe=s=>"'"+String(s||'').slice(0,80);const section=(a,b)=>KEY.slice(a,b).reduce((s,k,i)=>s+(k===p.answers[a+i]?1:0),0);
 sh.appendRow([p.id,new Date(),safe(p.name.trim()),safe(p.group),score,score*2.5,Math.round(p.seconds),section(0,12),section(12,26),section(26,40),...p.answers.map(a=>a+1)]);return {ok:true,score};
 }finally{lock.releaseLock();}
}
